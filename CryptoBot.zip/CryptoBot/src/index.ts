import Client from './classes/ClientEmitter';

export = Client;
